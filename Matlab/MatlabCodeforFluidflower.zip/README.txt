experiment_to_mesh contains a few figures that you can show in class to explain how you go from the experimental setup to the grid (this is directly from the medium fluidflower). 

mrstExample contains the code and input files. This is a simplified version of what we did for the fluidflower: The script is called exampleCO2inj and is thoroughly commented and included in .mlx version for better display from within Matlab. The code files for generating the mesh are not included, let me know if they are of interest.

I tested the code with the current version of mrst (2022a, https://www.sintef.no/projectweb/mrst/download/).
